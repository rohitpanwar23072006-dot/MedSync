
package com.medsync.medsync.controller;

import com.medsync.medsync.dto.UserResponse;
import com.medsync.medsync.model.*;
import com.medsync.medsync.service.AdminService;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final AdminService service;

    public AdminController(AdminService s) {
        service = s;
    }

    @GetMapping("/stats")
    public Map<String, Object> stats() {
        return service.stats();
    }

    @GetMapping("/users")
    public List<UserResponse> users(
            @RequestParam(required = false) String q) {
        return service.users(q)
                .stream()
                .map(UserResponse::new)
                .toList();
    }

    @PatchMapping("/users/{id}/active")
    public UserResponse active(
            Authentication a,
            @PathVariable Long id,
            @RequestBody Map<String, Boolean> r) {
        return new UserResponse(
                service.activate(
                        id,
                        Boolean.TRUE.equals(r.get("active")),
                        a.getName()
                )
        );
    }

    @PatchMapping("/doctors/{id}/verification")
    public UserResponse verifyDoctor(
            Authentication a,
            @PathVariable Long id,
            @RequestBody Map<String, Boolean> r) {
        return new UserResponse(
                service.verify(
                        id,
                        Boolean.TRUE.equals(r.get("approved")),
                        a.getName()
                )
        );
    }

    @PatchMapping("/pharmacists/{id}/verification")
    public UserResponse verifyPharmacist(
            Authentication a,
            @PathVariable Long id,
            @RequestBody Map<String, Boolean> r) {
        return new UserResponse(
                service.verify(
                        id,
                        Boolean.TRUE.equals(r.get("approved")),
                        a.getName()
                )
        );
    }

    @GetMapping("/appointments")
    public List<Appointment> appointments() {
        return service.appointments();
    }

    @GetMapping("/logs")
    public List<ActivityLog> logs() {
        return service.logs();
    }
}
