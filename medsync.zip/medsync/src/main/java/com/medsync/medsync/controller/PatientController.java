
package com.medsync.medsync.controller;

import com.medsync.medsync.model.MedicalRecord;
import com.medsync.medsync.model.MedicationReminder;
import com.medsync.medsync.model.PrescriptionItem;
import com.medsync.medsync.model.User;

import com.medsync.medsync.repository.MedicalRecordRepository;
import com.medsync.medsync.repository.MedicationReminderRepository;
import com.medsync.medsync.repository.PrescriptionItemRepository;

import com.medsync.medsync.service.AuthService;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/patient")
@PreAuthorize("hasRole('PATIENT')")
public class PatientController {

    private final MedicalRecordRepository records;
    private final MedicationReminderRepository reminders;
    private final PrescriptionItemRepository items;
    private final AuthService auth;

    public PatientController(
            MedicalRecordRepository records,
            MedicationReminderRepository reminders,
            PrescriptionItemRepository items,
            AuthService auth) {
        this.records = records;
        this.reminders = reminders;
        this.items = items;
        this.auth = auth;
    }

    @GetMapping("/records")
    public List<MedicalRecord> records(Authentication authentication) {
        User patient = auth.require(authentication.getName());

        return records.findByPatientIdOrderByCreatedAtDesc(
                patient.getId()
        );
    }

    @GetMapping("/reminders")
    public List<MedicationReminder> reminders(
            Authentication authentication) {
        User patient = auth.require(authentication.getName());

        return reminders.findByPatientIdOrderByCreatedAtDesc(
                patient.getId()
        );
    }

    @PostMapping("/reminders/{itemId}")
    public MedicationReminder createReminder(
            Authentication authentication,
            @PathVariable Long itemId,
            @RequestBody Map<String, String> body) {

        User patient = auth.require(authentication.getName());

        PrescriptionItem item = items.findById(itemId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Prescription item not found"
                        )
                );

        if (!item.getPrescription().getPatient().getId()
                .equals(patient.getId())) {
            throw new AccessDeniedException(
                    "Not your prescription item"
            );
        }

        MedicationReminder reminder = new MedicationReminder();
        reminder.setPatient(patient);
        reminder.setPrescriptionItem(item);
        reminder.setReminderTime(
                body.getOrDefault("reminderTime", "08:00")
        );
        reminder.setStatus("PENDING");

        return reminders.save(reminder);
    }

    @PatchMapping("/reminders/{id}")
    public MedicationReminder reminder(
            Authentication authentication,
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {

        MedicationReminder reminder = reminders.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Reminder not found")
                );

        if (!reminder.getPatient().getEmail()
                .equals(authentication.getName())) {
            throw new AccessDeniedException("Not your reminder");
        }

        String status = body.get("status");

        if (!List.of("TAKEN", "MISSED", "PENDING").contains(status)) {
            throw new IllegalArgumentException("Invalid status");
        }

        reminder.setStatus(status);

        return reminders.save(reminder);
    }
}
