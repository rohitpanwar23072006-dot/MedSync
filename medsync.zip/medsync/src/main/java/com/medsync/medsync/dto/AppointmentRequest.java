package com.medsync.medsync.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

public class AppointmentRequest {
    @NotNull
    private Long doctorId;
    @NotNull
    private LocalDateTime appointmentTime;
    private String reason;

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long v) {
        doctorId = v;
    }

    public LocalDateTime getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(LocalDateTime v) {
        appointmentTime = v;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String v) {
        reason = v;
    }
}
