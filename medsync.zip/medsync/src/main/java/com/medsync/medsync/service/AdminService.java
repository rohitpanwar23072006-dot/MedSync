
package com.medsync.medsync.service;

import com.medsync.medsync.model.*;
import com.medsync.medsync.repository.*;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class AdminService {

    private final UserRepository users;
    private final AppointmentRepository appointments;
    private final MedicineRepository medicines;
    private final ActivityLogRepository logs;
    private final AuthService auth;

    public AdminService(
            UserRepository users,
            AppointmentRepository appointments,
            MedicineRepository medicines,
            ActivityLogRepository logs,
            AuthService auth) {
        this.users = users;
        this.appointments = appointments;
        this.medicines = medicines;
        this.logs = logs;
        this.auth = auth;
    }

    public Map<String, Object> stats() {
        Map<String, Object> stats = new LinkedHashMap<>();

        stats.put("users", users.count());
        stats.put("patients", users.findByRole("PATIENT").size());

        stats.put(
                "doctorsPending",
                users.findByRole("DOCTOR")
                        .stream()
                        .filter(user -> !user.isVerified())
                        .count()
        );

        stats.put("appointments", appointments.count());
        stats.put("medicines", medicines.count());

        return stats;
    }

    public List<User> users(String query) {
        if (query == null || query.isBlank()) {
            return users.findAll();
        }

        String search = query.trim().toLowerCase();

        return users.findAll()
                .stream()
                .filter(user ->
                        (user.getEmail() != null &&
                         user.getEmail().toLowerCase().contains(search))
                        ||
                        (user.getFullName() != null &&
                         user.getFullName().toLowerCase().contains(search))
                        ||
                        (user.getRole() != null &&
                         user.getRole().toLowerCase().contains(search))
                )
                .toList();
    }

    @Transactional
    public User activate(Long id, boolean active, String actor) {
        User user = users.findById(id).orElseThrow();

        user.setActive(active);
        users.save(user);

        auth.log(
                actor,
                active ? "USER_ACTIVATED" : "USER_DEACTIVATED",
                user.getEmail()
        );

        return user;
    }

    @Transactional
    public User verify(Long id, boolean approved, String actor) {
        User user = users.findById(id).orElseThrow();

        String role = user.getRole();

        if (role == null ||
                (!role.equalsIgnoreCase("DOCTOR") &&
                 !role.equalsIgnoreCase("PHARMACIST"))) {
            throw new IllegalArgumentException(
                    "User is not a doctor or pharmacist"
            );
        }

        user.setVerified(approved);

        // A rejected pharmacist account is deactivated.
        if (role.equalsIgnoreCase("PHARMACIST") && !approved) {
            user.setActive(false);
        }

        users.save(user);

        String action = role.toUpperCase()
                + (approved ? "_APPROVED" : "_REJECTED");

        auth.log(actor, action, user.getEmail());

        return user;
    }

    public List<Appointment> appointments() {
        return appointments.findAll();
    }

    public List<ActivityLog> logs() {
        return logs.findAll();
    }
}
