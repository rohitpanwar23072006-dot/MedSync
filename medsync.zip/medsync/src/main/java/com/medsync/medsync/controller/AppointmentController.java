package com.medsync.medsync.controller;

import com.medsync.medsync.dto.AppointmentRequest;
import com.medsync.medsync.model.Appointment;
import com.medsync.medsync.service.AppointmentService;
import com.medsync.medsync.service.AuthService;
import org.springframework.security.access.AccessDeniedException;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {
    private final AppointmentService service;
    private final AuthService auth;

    public AppointmentController(AppointmentService s, AuthService auth) {
        service = s;
        this.auth = auth;
    }

    @PostMapping
    @PreAuthorize("hasRole('PATIENT')")
    public Appointment book(Authentication a, @Valid @RequestBody AppointmentRequest r) {
        return service.book(a.getName(), r);
    }

    @GetMapping("/mine")
    @PreAuthorize("hasAnyRole('PATIENT','DOCTOR')")
    public List<Appointment> mine(Authentication a) {
        boolean patient = a.getAuthorities().stream().anyMatch(x -> x.getAuthority().equals("ROLE_PATIENT"));
        if (!patient) {
            var doctor = auth.require(a.getName());
            if (!doctor.isActive() || !doctor.isVerified())
                throw new AccessDeniedException("Doctor account must be active and verified.");
        }
        return service.mine(a.getName(), patient ? "PATIENT" : "DOCTOR");
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('DOCTOR')")
    public Appointment status(Authentication a, @PathVariable Long id, @RequestBody Map<String, String> r) {
        var doctor = auth.require(a.getName());
        if (!doctor.isActive() || !doctor.isVerified())
            throw new AccessDeniedException("Doctor account must be active and verified.");
        return service.status(a.getName(), id, r.get("status"));
    }
}
