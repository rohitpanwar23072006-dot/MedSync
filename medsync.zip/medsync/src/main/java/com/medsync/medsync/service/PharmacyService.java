package com.medsync.medsync.service;

import com.medsync.medsync.model.Medicine;
import com.medsync.medsync.model.MedicineOrder;
import com.medsync.medsync.model.PrescriptionItem;
import com.medsync.medsync.model.User;

import com.medsync.medsync.repository.MedicineOrderRepository;
import com.medsync.medsync.repository.MedicineRepository;
import com.medsync.medsync.repository.PrescriptionItemRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@Service
public class PharmacyService {

    private final MedicineRepository medicines;
    private final MedicineOrderRepository orders;
    private final PrescriptionItemRepository prescriptionItems;
    private final AuthService auth;

    public PharmacyService(
            MedicineRepository medicines,
            MedicineOrderRepository orders,
            PrescriptionItemRepository prescriptionItems,
            AuthService auth) {

        this.medicines = medicines;
        this.orders = orders;
        this.prescriptionItems = prescriptionItems;
        this.auth = auth;
    }

    @Transactional(readOnly = true)
    public List<Medicine> list() {

        return medicines.findAll()
                .stream()
                .filter(this::isAvailable)
                .sorted(Comparator.comparing(this::calculateTotalPrice))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<Medicine> search(String name) {

        if (name == null || name.isBlank()) {
            return list();
        }

        return medicines
                .findByNameContainingIgnoreCaseAndActiveTrue(name.trim())
                .stream()
                .filter(this::isAvailable)
                .sorted(Comparator.comparing(this::calculateTotalPrice))
                .toList();
    }

    private boolean isAvailable(Medicine medicine) {

        return medicine.isActive()
                && medicine.getStockQuantity() > 0
                && medicine.getPrice() != null
                && medicine.getPharmacist() != null
                && medicine.getPharmacist().isActive()
                && medicine.getPharmacist().isVerified();
    }

    public BigDecimal calculateTotalPrice(Medicine medicine) {

        BigDecimal price = medicine.getPrice();

        User pharmacist = medicine.getPharmacist();

        BigDecimal deliveryCharge = pharmacist.getDeliveryCharge();

        if (deliveryCharge == null) {
            deliveryCharge = BigDecimal.ZERO;
        }

        return price.add(deliveryCharge);
    }

    @Transactional
    public Medicine save(String email, Medicine medicine) {

        if (medicine.getStockQuantity() < 0
                || medicine.getLowStockThreshold() < 0
                || medicine.getPrice() == null
                || medicine.getPrice().signum() < 0) {

            throw new IllegalArgumentException(
                    "Stock, threshold and price must be non-negative"
            );
        }

        User pharmacist = auth.require(email);

        if (medicine.getId() != null) {

            Medicine existing = medicines.findById(medicine.getId())
                    .orElseThrow();

            if (existing.getPharmacist() == null
                    || !existing.getPharmacist().getId()
                            .equals(pharmacist.getId())) {

                throw new IllegalArgumentException(
                        "You cannot update another pharmacy's medicine"
                );
            }
        }

        medicine.setPharmacist(pharmacist);
        medicine.setActive(true);

        Medicine saved = medicines.save(medicine);

        auth.log(email, "MEDICINE_SAVED", saved.getName());

        return saved;
    }

    @Transactional(readOnly = true)
    public List<MedicineOrder> allOrders(String email) {

        User pharmacist = auth.require(email);

        return orders.findAll()
                .stream()
                .filter(order ->
                        order.getMedicine() != null
                        && order.getMedicine().getPharmacist() != null
                        && order.getMedicine()
                                .getPharmacist()
                                .getId()
                                .equals(pharmacist.getId()))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<PrescriptionItem> myPrescribedMedicines(String email) {

        User patient = auth.require(email);

        if (!"PATIENT".equals(patient.getRole())) {
            throw new IllegalArgumentException(
                    "Only patients can view their prescribed medicines"
            );
        }

        return prescriptionItems.findByPrescriptionPatientId(
                patient.getId()
        );
    }

    @Transactional
    public MedicineOrder order(
            String email,
            Long medicineId,
            int quantity) {

        User patient = auth.require(email);

        List<PrescriptionItem> matchingItems =
                prescriptionItems.findByPrescriptionPatientId(
                        patient.getId()
                );

        Medicine medicine = medicines.findById(medicineId)
                .orElseThrow();

        PrescriptionItem matchingItem = matchingItems.stream()
                .filter(item ->
                        item.getMedicineName() != null
                        && medicine.getName() != null
                        && item.getMedicineName().trim()
                                .toLowerCase(Locale.ROOT)
                                .equals(
                                        medicine.getName().trim()
                                                .toLowerCase(Locale.ROOT)
                                ))
                .findFirst()
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "This medicine is not in your prescription"
                        )
                );

        return placeOrder(patient, medicine, matchingItem, quantity);
    }

    @Transactional
    public MedicineOrder orderFromPrescription(
            String email,
            Long medicineId,
            Long prescriptionItemId,
            int quantity) {

        User patient = auth.require(email);

        PrescriptionItem prescriptionItem =
                prescriptionItems.findById(prescriptionItemId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Prescription item not found"
                                )
                        );

        if (!prescriptionItem.getPrescription()
                .getPatient().getId().equals(patient.getId())) {

            throw new IllegalArgumentException(
                    "This prescription does not belong to you"
            );
        }

        Medicine medicine = medicines.findById(medicineId)
                .orElseThrow();

        if (medicine.getName() == null
                || prescriptionItem.getMedicineName() == null
                || !medicine.getName().trim()
                        .equalsIgnoreCase(
                                prescriptionItem.getMedicineName().trim()
                        )) {

            throw new IllegalArgumentException(
                    "Selected medicine does not match the prescription"
            );
        }

        return placeOrder(
                patient,
                medicine,
                prescriptionItem,
                quantity
        );
    }

    private MedicineOrder placeOrder(
            User patient,
            Medicine medicine,
            PrescriptionItem prescriptionItem,
            int quantity) {

        if (!"PATIENT".equals(patient.getRole())
                || !patient.isActive()) {

            throw new IllegalArgumentException(
                    "An active patient account is required"
            );
        }

        if (quantity < 1) {
            throw new IllegalArgumentException(
                    "Quantity must be at least one"
            );
        }

        if (!medicine.isActive()
                || medicine.getStockQuantity() < quantity
                || medicine.getPrice() == null) {

            throw new IllegalArgumentException(
                    "Medicine is unavailable or stock is insufficient"
            );
        }

        User pharmacist = medicine.getPharmacist();

        if (pharmacist == null
                || !pharmacist.isActive()
                || !pharmacist.isVerified()) {

            throw new IllegalArgumentException(
                    "Pharmacy is unavailable"
            );
        }

        medicine.setStockQuantity(
                medicine.getStockQuantity() - quantity
        );

        medicines.save(medicine);

        MedicineOrder order = new MedicineOrder();

        order.setPatient(patient);
        order.setMedicine(medicine);
        order.setPrescriptionItem(prescriptionItem);
        order.setQuantity(quantity);

        BigDecimal medicineTotal = medicine.getPrice()
                .multiply(BigDecimal.valueOf(quantity));

        BigDecimal deliveryCharge = pharmacist.getDeliveryCharge();

        if (deliveryCharge == null) {
            deliveryCharge = BigDecimal.ZERO;
        }

        order.setTotalPrice(medicineTotal.add(deliveryCharge));
        order.setStatus("PLACED");

        return orders.save(order);
    }

    @Transactional
    public MedicineOrder orderStatus(
            String email,
            Long id,
            String status) {

        MedicineOrder order = orders.findById(id)
                .orElseThrow();

        User pharmacist = auth.require(email);

        if (order.getMedicine().getPharmacist() == null
                || !order.getMedicine()
                        .getPharmacist()
                        .getId()
                        .equals(pharmacist.getId())) {

            throw new IllegalArgumentException(
                    "You cannot update another pharmacy's order"
            );
        }

        if (status == null || !List.of(
                "PLACED",
                "PROCESSING",
                "SHIPPED",
                "COMPLETED",
                "CANCELLED"
        ).contains(status)) {

            throw new IllegalArgumentException(
                    "Invalid order status"
            );
        }

        order.setStatus(status);

        return orders.save(order);
    }

    @Transactional(readOnly = true)
    public List<Medicine> myMedicines(String email) {

        User pharmacist = auth.require(email);

        return medicines.findByPharmacistId(pharmacist.getId());
    }
}