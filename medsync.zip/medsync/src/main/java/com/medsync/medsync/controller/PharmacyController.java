package com.medsync.medsync.controller;

import com.medsync.medsync.model.*;
import com.medsync.medsync.service.PharmacyService;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

@RestController
@RequestMapping("/api/pharmacy")
public class PharmacyController {

    private final PharmacyService service;

    public PharmacyController(PharmacyService service) {
        this.service = service;
    }

    // Get available medicines
    @GetMapping("/medicines")
    @PreAuthorize("hasAnyRole('PATIENT','PHARMACIST','ADMIN')")
    public List<Medicine> medicines() {
        return service.list();
    }

    // Search medicines
    @GetMapping("/medicines/search")
    @PreAuthorize("hasAnyRole('PATIENT','PHARMACIST','ADMIN')")
    public List<Medicine> searchMedicines(
            @RequestParam String name) {

        return service.search(name);
    }

    // Get medicines from patient's prescriptions
    @GetMapping("/prescribed-medicines")
    @PreAuthorize("hasRole('PATIENT')")
    public List<Map<String, Object>> prescribedMedicines(
            Authentication a) {

        return service.myPrescribedMedicines(a.getName())
                .stream()
                .map(item -> {

                    Map<String, Object> data = new LinkedHashMap<>();

                    data.put("id", item.getId());
                    data.put("medicineName", item.getMedicineName());
                    data.put("dosage", item.getDosage());
                    data.put("frequency", item.getFrequency());
                    data.put("duration", item.getDuration());
                    data.put("instructions", item.getInstructions());

                    return data;
                })
                .toList();
    }

    // Get pharmacist's inventory
    @GetMapping("/my-medicines")
    @PreAuthorize("hasRole('PHARMACIST')")
    public List<Medicine> myMedicines(Authentication a) {
        return service.myMedicines(a.getName());
    }

    // Add medicine
    @PostMapping("/medicines")
    @PreAuthorize("hasRole('PHARMACIST')")
    public Medicine save(
            Authentication a,
            @RequestBody Medicine medicine) {

        return service.save(a.getName(), medicine);
    }

    // Update medicine
    @PutMapping("/medicines/{id}")
    @PreAuthorize("hasRole('PHARMACIST')")
    public Medicine update(
            Authentication a,
            @PathVariable Long id,
            @RequestBody Medicine medicine) {

        medicine.setId(id);

        return service.save(a.getName(), medicine);
    }

    // Get orders received by the pharmacist
    @GetMapping("/orders")
    @PreAuthorize("hasRole('PHARMACIST')")
    @Transactional(readOnly = true)
    public List<Map<String, Object>> orders(Authentication a) {

        return service.allOrders(a.getName())
                .stream()
                .map(this::toOrderResponse)
                .toList();
    }

    // Place order using medicine ID
    @PostMapping("/orders/{medicineId}")
    @PreAuthorize("hasRole('PATIENT')")
    public Map<String, Object> order(
            Authentication a,
            @PathVariable Long medicineId,
            @RequestBody Map<String, Integer> request) {

        MedicineOrder order = service.order(
                a.getName(),
                medicineId,
                request.getOrDefault("quantity", 0));

        return toBasicOrderResponse(order);
    }

    // Place order using prescription
    @PostMapping("/orders/prescription/{medicineId}")
    @PreAuthorize("hasRole('PATIENT')")
    public Map<String, Object> orderFromPrescription(
            Authentication a,
            @PathVariable Long medicineId,
            @RequestBody Map<String, Long> request) {

        Long prescriptionItemId = request.get("prescriptionItemId");
        Long quantity = request.get("quantity");

        if (prescriptionItemId == null
                || quantity == null
                || quantity < 1
                || quantity > Integer.MAX_VALUE) {

            throw new IllegalArgumentException(
                    "Valid prescription item and quantity are required");
        }

        MedicineOrder order = service.orderFromPrescription(
                a.getName(),
                medicineId,
                prescriptionItemId,
                quantity.intValue());

        Map<String, Object> response = toBasicOrderResponse(order);

        response.put("medicineId", medicineId);
        response.put("prescriptionItemId", prescriptionItemId);

        return response;
    }

    // Get safe order details without Hibernate serialization errors
    private Map<String, Object> toBasicOrderResponse(
            MedicineOrder order) {

        Map<String, Object> response = new LinkedHashMap<>();

        response.put("id", order.getId());
        response.put("quantity", order.getQuantity());
        response.put("totalPrice", order.getTotalPrice());
        response.put("status", order.getStatus());
        response.put("createdAt", order.getCreatedAt());

        return response;
    }

    // Build order response for pharmacist dashboard
    private Map<String, Object> toOrderResponse(
            MedicineOrder order) {

        Map<String, Object> data = toBasicOrderResponse(order);

        Medicine medicine = order.getMedicine();
        User patient = order.getPatient();
        PrescriptionItem item = order.getPrescriptionItem();

        data.put("medicineName",
                medicine != null ? medicine.getName() : null);

        data.put("patientName",
                patient != null ? patient.getFullName() : null);

        data.put("prescriptionItemId",
                item != null ? item.getId() : null);

        // Keep nested fields for dashboard compatibility
        if (medicine != null) {
            Map<String, Object> medicineData = new LinkedHashMap<>();

            medicineData.put("id", medicine.getId());
            medicineData.put("name", medicine.getName());
            medicineData.put("price", medicine.getPrice());

            data.put("medicine", medicineData);
        }

        if (patient != null) {
            Map<String, Object> patientData = new LinkedHashMap<>();

            patientData.put("id", patient.getId());
            patientData.put("fullName", patient.getFullName());

            data.put("patient", patientData);
        }

        return data;
    }

    @PatchMapping("/orders/{id}")
    @PreAuthorize("hasRole('PHARMACIST')")
    public Map<String, Object> updateOrderStatus(
            Authentication a,
            @PathVariable Long id,
            @RequestBody Map<String, String> request) {

        String status = request.get("status");

        if (status == null || status.isBlank()) {
            throw new IllegalArgumentException("Order status is required");
        }

        MedicineOrder order = service.orderStatus(
                a.getName(),
                id,
                status.toUpperCase());

        Map<String, Object> response = new LinkedHashMap<>();

        response.put("id", order.getId());
        response.put("status", order.getStatus());
        response.put("quantity", order.getQuantity());
        response.put("totalPrice", order.getTotalPrice());

        return response;
    }
}