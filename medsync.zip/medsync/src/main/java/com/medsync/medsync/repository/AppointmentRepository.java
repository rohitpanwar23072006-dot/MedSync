package com.medsync.medsync.repository;

import com.medsync.medsync.model.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    List<Appointment> findByPatientIdOrderByAppointmentTimeDesc(Long id);

    List<Appointment> findByDoctorIdOrderByAppointmentTimeDesc(Long id);

}
