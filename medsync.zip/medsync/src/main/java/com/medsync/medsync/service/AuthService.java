package com.medsync.medsync.service;

import com.medsync.medsync.dto.SignupRequest;
import com.medsync.medsync.dto.UserResponse;
import com.medsync.medsync.model.ActivityLog;
import com.medsync.medsync.model.User;
import com.medsync.medsync.repository.ActivityLogRepository;
import com.medsync.medsync.repository.UserRepository;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
public class AuthService {

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final ActivityLogRepository logs;

    public AuthService(
            UserRepository users,
            PasswordEncoder encoder,
            ActivityLogRepository logs) {
        this.users = users;
        this.encoder = encoder;
        this.logs = logs;
    }

    @Transactional
    public UserResponse signup(SignupRequest request) {

        String role = request.getRole() == null
                ? ""
                : request.getRole().toUpperCase();

        if (!List.of("PATIENT", "DOCTOR", "PHARMACIST").contains(role)) {
            throw new IllegalArgumentException(
                    "Public signup is available for patients, doctors "
                    + "and pharmacists only"
            );
        }

        String email = request.getEmail().trim().toLowerCase();
        if (users.findByEmail(email).isPresent()) {
            throw new IllegalArgumentException(
                    "Email is already registered"
            );
        }

        if ("DOCTOR".equals(role)
                && (request.getLicenseNumber() == null || request.getLicenseNumber().isBlank()
                || request.getSpecialty() == null || request.getSpecialty().isBlank())) {
            throw new IllegalArgumentException(
                    "Doctors must provide a specialization and registration ID"
            );
        }

        if ("PHARMACIST".equals(role)
                && (request.getLicenseNumber() == null || request.getLicenseNumber().isBlank()
                || request.getAddress() == null || request.getAddress().isBlank())) {
            throw new IllegalArgumentException(
                    "Pharmacists must provide a pharmacy registration ID and address"
            );
        }

        User user = new User();

        user.setFullName(request.getFullName().trim());
        user.setEmail(email);
        user.setPassword(encoder.encode(request.getPassword()));
        user.setRole(role);
        user.setPhone(request.getPhone());
        user.setDateOfBirth(request.getDateOfBirth());
        user.setSpecialty(request.getSpecialty());
        user.setLicenseNumber(request.getLicenseNumber());
        user.setAddress(request.getAddress());

        if ("PHARMACIST".equals(role)) {

            if (request.getPharmacyName() == null
                    || request.getPharmacyName().isBlank()) {
                throw new IllegalArgumentException(
                        "Pharmacy name is required"
                );
            }

            if (request.getDeliveryCharge() == null
                    || request.getDeliveryCharge().signum() < 0) {
                throw new IllegalArgumentException(
                        "Delivery charge must be zero or greater"
                );
            }

            user.setPharmacyName(request.getPharmacyName().trim());
            user.setDeliveryCharge(request.getDeliveryCharge());
        }

        user.setActive(true);
        user.setVerified(role.equals("PATIENT"));

        users.save(user);

        log(user.getEmail(), "SIGNUP", role);

        return new UserResponse(user);
    }

    public UserResponse me(String email) {
        User user = users.findByEmail(email).orElseThrow();
        return new UserResponse(user);
    }

    public User require(String email) {
        return users.findByEmail(email)
                .orElseThrow(() ->
                        new IllegalArgumentException("User not found")
                );
    }

    public void log(String email, String action, String details) {
        ActivityLog activityLog = new ActivityLog();

        activityLog.setActorEmail(email);
        activityLog.setAction(action);
        activityLog.setDetails(details);

        logs.save(activityLog);
    }

    @Transactional
    public void createAdminIfMissing() {
        String email = "adminMedSync@gmail.com";

        if (users.findByEmail(email).isPresent()) {
            return;
        }

        User admin = new User();
        admin.setFullName("MedSync Administrator");
        admin.setEmail(email);
        admin.setPassword(encoder.encode("admin@1234"));
        admin.setRole("ADMIN");
        admin.setActive(true);
        admin.setVerified(true);

        users.save(admin);
        log(email, "ADMIN_CREATED", "Initial administrator account");
    }
    
}