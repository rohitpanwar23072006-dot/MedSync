
package com.medsync.medsync.controller;

import com.medsync.medsync.model.Appointment;
import com.medsync.medsync.model.MedicalRecord;
import com.medsync.medsync.model.User;
import com.medsync.medsync.repository.AppointmentRepository;
import com.medsync.medsync.repository.MedicalRecordRepository;
import com.medsync.medsync.repository.UserRepository;
import com.medsync.medsync.service.AuthService;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/doctor")
@PreAuthorize("hasRole('DOCTOR')")
public class DoctorController {

    private final MedicalRecordRepository records;
    private final UserRepository users;
    private final AppointmentRepository appointments;
    private final AuthService auth;

    public DoctorController(
            MedicalRecordRepository records,
            UserRepository users,
            AppointmentRepository appointments,
            AuthService auth) {
        this.records = records;
        this.users = users;
        this.appointments = appointments;
        this.auth = auth;
    }

    @PostMapping("/records")
    public MedicalRecord record(
            Authentication authentication,
            @RequestBody Map<String, String> body) {

        User doctor = getVerifiedDoctor(authentication.getName());

        String patientId = body.get("patientId");
        String title = body.get("title");

        if (patientId == null || patientId.isBlank()) {
            throw new IllegalArgumentException(
                    "Patient ID is required"
            );
        }

        if (title == null || title.isBlank()) {
            throw new IllegalArgumentException(
                    "Record title is required"
            );
        }

        Long id;

        try {
            id = Long.valueOf(patientId);
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(
                    "Patient ID must be a valid number"
            );
        }

        User patient = users.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Patient not found")
                );

        if (!"PATIENT".equals(patient.getRole())) {
            throw new IllegalArgumentException("Patient not found");
        }

        MedicalRecord record = new MedicalRecord();
        record.setPatient(patient);
        record.setDoctor(doctor);
        record.setTitle(title);
        record.setNotes(body.get("notes"));

        return records.save(record);
    }

    @GetMapping("/patients/{id}/records")
    public List<MedicalRecord> patientRecords(
            Authentication authentication,
            @PathVariable Long id) {

        User doctor = getVerifiedDoctor(authentication.getName());

        User patient = users.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Patient not found")
                );

        if (!"PATIENT".equals(patient.getRole())) {
            throw new IllegalArgumentException("Patient not found");
        }

        List<MedicalRecord> patientRecords =
                records.findByPatientIdOrderByCreatedAtDesc(id);

        boolean hasAccess = patientRecords.stream()
                .anyMatch(record ->
                        record.getDoctor().getId().equals(doctor.getId())
                );

        if (!hasAccess) {
            List<Appointment> doctorAppointments =
                    appointments.findByDoctorIdOrderByAppointmentTimeDesc(
                            doctor.getId()
                    );

            hasAccess = doctorAppointments.stream()
                    .anyMatch(appointment ->
                            appointment.getPatient().getId().equals(id)
                    );
        }

        if (!hasAccess) {
            throw new AccessDeniedException(
                    "You do not have access to this patient's records"
            );
        }

        return patientRecords;
    }

    private User getVerifiedDoctor(String email) {
        User doctor = auth.require(email);

        if (!doctor.isVerified() || !doctor.isActive()) {
            throw new AccessDeniedException(
                    "Doctor account is inactive or not verified"
            );
        }

        return doctor;
    }
}
