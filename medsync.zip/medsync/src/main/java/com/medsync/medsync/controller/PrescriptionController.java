package com.medsync.medsync.controller;

import com.medsync.medsync.dto.PrescriptionRequest;
import com.medsync.medsync.model.*;
import com.medsync.medsync.service.PrescriptionService;
import com.medsync.medsync.service.AuthService;
import org.springframework.security.access.AccessDeniedException;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/prescriptions")
public class PrescriptionController {
    private final PrescriptionService service;
    private final AuthService auth;

    public PrescriptionController(PrescriptionService s, AuthService auth) {
        service = s;
        this.auth = auth;
    }

    @PostMapping
    @PreAuthorize("hasRole('DOCTOR')")
    public Prescription create(Authentication a, @Valid @RequestBody PrescriptionRequest r) {
        return service.create(a.getName(), r);
    }

    @GetMapping("/mine")
    @PreAuthorize("hasAnyRole('PATIENT','DOCTOR')")
    public List<Prescription> mine(Authentication a) {
        boolean patient = a.getAuthorities().stream().anyMatch(x -> x.getAuthority().equals("ROLE_PATIENT"));
        if (!patient) {
            var doctor = auth.require(a.getName());
            if (!doctor.isActive() || !doctor.isVerified())
                throw new AccessDeniedException("Doctor account must be active and verified.");
        }
        return patient ? service.patient(a.getName()) : service.doctor(a.getName());
    }

    @GetMapping("/{id}/items")
    @PreAuthorize("hasAnyRole('PATIENT','DOCTOR')")
    public List<PrescriptionItem> items(Authentication a, @PathVariable Long id) {
        boolean patient = a.getAuthorities().stream().anyMatch(x -> x.getAuthority().equals("ROLE_PATIENT"));
        if (!patient) {
            var doctor = auth.require(a.getName());
            if (!doctor.isActive() || !doctor.isVerified())
                throw new AccessDeniedException("Doctor account must be active and verified.");
        }
        return service.items(id, a.getName());
    }
}
