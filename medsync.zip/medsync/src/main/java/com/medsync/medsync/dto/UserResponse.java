package com.medsync.medsync.dto;

import com.medsync.medsync.model.User;

public class UserResponse {
    public Long id;
    public String fullName;
    public String email;
    public String role;
    public String phone;
    public String dateOfBirth;
    public String specialty;
    public String licenseNumber;
    public String address;
    public boolean active;
    public boolean verified;

    public UserResponse(User user) {
        id = user.getId();
        fullName = user.getFullName();
        email = user.getEmail();
        role = user.getRole();
        phone = user.getPhone();
        dateOfBirth = user.getDateOfBirth();
        specialty = user.getSpecialty();
        licenseNumber = user.getLicenseNumber();
        address = user.getAddress();
        active = user.isActive();
        verified = user.isVerified();
    }
}
