package com.medsync.medsync.repository;

import com.medsync.medsync.model.Prescription;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PrescriptionRepository extends JpaRepository<Prescription, Long> {

    List<Prescription> findByPatientIdOrderByCreatedAtDesc(Long id);

    List<Prescription> findByDoctorIdOrderByCreatedAtDesc(Long id);

}
