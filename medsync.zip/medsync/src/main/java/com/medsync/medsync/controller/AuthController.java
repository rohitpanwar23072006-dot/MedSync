
package com.medsync.medsync.controller;

import com.medsync.medsync.dto.SignupRequest;
import com.medsync.medsync.dto.UserResponse;
import com.medsync.medsync.service.AuthService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService service;
    private final AuthenticationManager manager;

    private final SecurityContextRepository contexts =
            new HttpSessionSecurityContextRepository();

    public AuthController(
            AuthService service,
            AuthenticationManager manager) {
        this.service = service;
        this.manager = manager;
    }

    @PostMapping("/signup")
    public UserResponse signup(@Valid @RequestBody SignupRequest request) {
        return service.signup(request);
    }

    @PostMapping("/login")
    public ResponseEntity<UserResponse> login(
            @RequestBody Map<String, String> request,
            HttpServletRequest httpRequest,
            HttpServletResponse httpResponse) {

        Authentication authentication = manager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getOrDefault("email", "").trim().toLowerCase(),
                        request.get("password")
                )
        );

        SecurityContext context =
                SecurityContextHolder.createEmptyContext();

        context.setAuthentication(authentication);
        SecurityContextHolder.setContext(context);

        contexts.saveContext(context, httpRequest, httpResponse);

        return ResponseEntity.ok(service.me(authentication.getName()));
    }

    @GetMapping("/me")
    public UserResponse me(Authentication authentication) {
        return service.me(authentication.getName());
    }

    @PostMapping("/logout")
    public Map<String, String> logout(
            HttpServletRequest request,
            HttpServletResponse response) {

        new SecurityContextLogoutHandler()
                .logout(request, response, null);

        return Map.of("message", "Logged out");
    }
    @GetMapping("/check-role")
        public Map<String, Object> checkRole(Authentication authentication) {
        return Map.of(
                "email", authentication.getName(),
                "authorities", authentication.getAuthorities().toString()
        );
        }
}
