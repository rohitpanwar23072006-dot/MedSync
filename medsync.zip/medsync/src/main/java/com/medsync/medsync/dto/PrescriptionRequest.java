package com.medsync.medsync.dto;

import jakarta.validation.constraints.*;
import java.util.List;

public class PrescriptionRequest {
    @NotNull
    public Long patientId;
    public Long appointmentId;
    public String notes;
    @NotEmpty
    public List<Item> items;

    public static class Item {
        @NotBlank
        public String medicineName;
        @NotBlank
        public String dosage;
        @NotBlank
        public String frequency;
        @NotBlank
        public String duration;
        public String instructions;
    }
}
