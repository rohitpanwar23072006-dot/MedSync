package com.medsync.medsync.controller;

import com.medsync.medsync.dto.UserResponse;
import com.medsync.medsync.repository.UserRepository;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/doctors")
public class DirectoryController {
    private final UserRepository users;

    public DirectoryController(UserRepository u) {
        users = u;
    }

    @GetMapping
    public List<UserResponse> doctors() {
        return users.findByRoleAndVerifiedTrueAndActiveTrue("DOCTOR").stream().map(UserResponse::new).toList();
    }
}
