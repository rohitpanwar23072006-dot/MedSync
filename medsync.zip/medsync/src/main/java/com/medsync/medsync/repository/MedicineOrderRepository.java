package com.medsync.medsync.repository;

import com.medsync.medsync.model.MedicineOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MedicineOrderRepository extends JpaRepository<MedicineOrder, Long> {

    List<MedicineOrder> findByPatientIdOrderByCreatedAtDesc(Long id);

}