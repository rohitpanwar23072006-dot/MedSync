package com.medsync.medsync.service;

import com.medsync.medsync.dto.PrescriptionRequest;
import com.medsync.medsync.model.Appointment;
import com.medsync.medsync.model.Prescription;
import com.medsync.medsync.model.PrescriptionItem;
import com.medsync.medsync.model.User;
import com.medsync.medsync.repository.AppointmentRepository;
import com.medsync.medsync.repository.PrescriptionItemRepository;
import com.medsync.medsync.repository.PrescriptionRepository;
import com.medsync.medsync.repository.UserRepository;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PrescriptionService {

    private final PrescriptionRepository prescriptions;
    private final PrescriptionItemRepository items;
    private final UserRepository users;
    private final AppointmentRepository appointments;
    private final AuthService auth;

    public PrescriptionService(
            PrescriptionRepository prescriptions,
            PrescriptionItemRepository items,
            UserRepository users,
            AppointmentRepository appointments,
            AuthService auth) {

        this.prescriptions = prescriptions;
        this.items = items;
        this.users = users;
        this.appointments = appointments;
        this.auth = auth;
    }

    @Transactional
    public Prescription create(String email, PrescriptionRequest request) {

        User doctor = auth.require(email);

        if (!doctor.getRole().equals("DOCTOR") || !doctor.isVerified()) {
            throw new AccessDeniedException("Verified doctors only");
        }

        if (request.appointmentId == null) {
            throw new IllegalArgumentException(
                    "An accepted appointment is required before prescribing"
            );
        }

        Appointment appointment = appointments
                .findById(request.appointmentId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Appointment not found")
                );

        User patient = appointment.getPatient();

        if (!"PATIENT".equals(patient.getRole())) {
            throw new IllegalArgumentException(
                    "Appointment does not belong to a patient"
            );
        }

        if (!appointment.getDoctor().getId().equals(doctor.getId())) {
            throw new AccessDeniedException(
                    "This appointment does not belong to you"
            );
        }

        if (!"CONFIRMED".equals(appointment.getStatus())) {
            throw new IllegalArgumentException(
                    "Confirm the appointment before creating a prescription"
            );
        }

        Prescription prescription = new Prescription();

        prescription.setDoctor(doctor);
        prescription.setPatient(patient);
        prescription.setNotes(request.notes);
        prescription.setAppointment(appointment);

        prescriptions.save(prescription);

        for (PrescriptionRequest.Item itemRequest : request.items) {

            PrescriptionItem item = new PrescriptionItem();

            item.setPrescription(prescription);
            item.setMedicineName(itemRequest.medicineName);
            item.setDosage(itemRequest.dosage);
            item.setFrequency(itemRequest.frequency);
            item.setDuration(itemRequest.duration);
            item.setInstructions(itemRequest.instructions);

            items.save(item);
        }

        auth.log(
                email,
                "PRESCRIPTION_CREATED",
                "Prescription #" + prescription.getId()
        );

        return prescription;
    }

    @Transactional(readOnly = true)
    public List<Prescription> patient(String email) {

        User user = auth.require(email);

        return prescriptions.findByPatientIdOrderByCreatedAtDesc(
                user.getId()
        );
    }

    @Transactional(readOnly = true)
    public List<Prescription> doctor(String email) {

        User user = auth.require(email);

        return prescriptions.findByDoctorIdOrderByCreatedAtDesc(
                user.getId()
        );
    }

    @Transactional(readOnly = true)
    public List<PrescriptionItem> items(Long id, String email) {

        Prescription prescription = prescriptions.findById(id)
                .orElseThrow();

        if (!prescription.getPatient().getEmail().equals(email)
                && !prescription.getDoctor().getEmail().equals(email)) {

            throw new AccessDeniedException("Not your prescription");
        }

        return items.findByPrescriptionId(id);
    }
}