
package com.medsync.medsync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.medsync.medsync.service.AuthService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MedSyncApplication {

    public static void main(String[] args) {
        SpringApplication.run(MedSyncApplication.class, args);
    }

    @Bean
    CommandLineRunner createAdmin(AuthService authService) {
        return args -> authService.createAdminIfMissing();
    }
}
