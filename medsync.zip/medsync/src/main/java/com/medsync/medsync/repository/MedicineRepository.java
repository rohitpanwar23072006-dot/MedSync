package com.medsync.medsync.repository;

import com.medsync.medsync.model.Medicine;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MedicineRepository extends JpaRepository<Medicine, Long> {

    List<Medicine> findByActiveTrue();

    List<Medicine> findByPharmacistId(Long pharmacistId);

    List<Medicine> findByNameContainingIgnoreCaseAndActiveTrue(String name);
}