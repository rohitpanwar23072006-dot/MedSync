
package com.medsync.medsync.service;

import com.medsync.medsync.dto.AppointmentRequest;
import com.medsync.medsync.model.Appointment;
import com.medsync.medsync.model.User;
import com.medsync.medsync.repository.AppointmentRepository;
import com.medsync.medsync.repository.UserRepository;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AppointmentService {

    private final AppointmentRepository appointments;
    private final UserRepository users;
    private final AuthService auth;

    public AppointmentService(
            AppointmentRepository appointments,
            UserRepository users,
            AuthService auth) {
        this.appointments = appointments;
        this.users = users;
        this.auth = auth;
    }

    @Transactional
    public Appointment book(String email, AppointmentRequest request) {
        User patient = auth.require(email);

        User doctor = users.findById(request.getDoctorId())
                .orElseThrow();

        if (!doctor.getRole().equals("DOCTOR")
                || !doctor.isVerified()
                || !doctor.isActive()) {
            throw new IllegalArgumentException(
                    "Doctor is not available for booking"
            );
        }

        if (request.getAppointmentTime().isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException(
                    "Appointment must be in the future"
            );
        }

        Appointment appointment = new Appointment();
        appointment.setPatient(patient);
        appointment.setDoctor(doctor);
        appointment.setAppointmentTime(request.getAppointmentTime());
        appointment.setReason(request.getReason());
        appointment.setStatus("PENDING");

        return appointments.save(appointment);
    }

    public List<Appointment> mine(String email, String role) {
        User user = auth.require(email);

        if (role.equals("PATIENT")) {
            return appointments.findByPatientIdOrderByAppointmentTimeDesc(
                    user.getId()
            );
        }

        return appointments.findByDoctorIdOrderByAppointmentTimeDesc(
                user.getId()
        );
    }

    @Transactional
    public Appointment status(String email, Long id, String status) {
        Appointment appointment = appointments.findById(id)
                .orElseThrow();

        if (!appointment.getDoctor().getEmail().equals(email)) {
            throw new AccessDeniedException("Not your appointment");
        }

        if (!List.of(
                "CONFIRMED",
                "COMPLETED",
                "CANCELLED",
                "REJECTED"
        ).contains(status)) {
            throw new IllegalArgumentException(
                    "Invalid appointment status"
            );
        }

        appointment.setStatus(status);

        return appointments.save(appointment);
    }
}
