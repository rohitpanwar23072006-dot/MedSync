package com.medsync.medsync.repository;

import com.medsync.medsync.model.MedicationReminder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MedicationReminderRepository extends JpaRepository<MedicationReminder, Long> {

    List<MedicationReminder> findByPatientIdOrderByCreatedAtDesc(Long id);

}
