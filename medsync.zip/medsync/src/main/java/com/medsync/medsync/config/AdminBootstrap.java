package com.medsync.medsync.config;

import com.medsync.medsync.model.User;
import com.medsync.medsync.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class AdminBootstrap {
    @Bean
    CommandLineRunner createInitialAdmin(UserRepository users, PasswordEncoder encoder) {
        return args -> {
            String email = System.getenv("MEDSYNC_ADMIN_EMAIL"), password = System.getenv("MEDSYNC_ADMIN_PASSWORD");
            if (email != null && !email.isBlank() && password != null && password.length() >= 12
                    && users.findByEmail(email).isEmpty()) {
                User u = new User();
                u.setFullName("MedSync Administrator");
                u.setEmail(email.toLowerCase());
                u.setPassword(encoder.encode(password));
                u.setRole("ADMIN");
                u.setActive(true);
                u.setVerified(true);
                users.save(u);
                System.out.println("Initial MedSync admin created: " + email);
            }
        };
    }
}
